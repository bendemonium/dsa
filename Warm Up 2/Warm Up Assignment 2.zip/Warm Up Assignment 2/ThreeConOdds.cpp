class Solution {
public:
    bool threeConsecutiveOdds(vector<int>& arr) {
        vector<int> odds;
        bool set=false;
        int n=arr.size();
        for (int i=0;i<n-2;i++){
            if (arr[i+2]%2!=0 && arr[i+1]%2!=0 && arr[i]%2!=0)
                set=true;
        }
        return set;
    };
};